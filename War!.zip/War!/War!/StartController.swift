//
//  ViewController.swift
//  War!
//
//  Created by David Richardson on 12/18/16.
//  Copyright © 2016 David Richardson. All rights reserved.
//

import UIKit

class StartController: UIViewController {

    @IBOutlet weak var p2Name: UITextField!
    @IBOutlet weak var p1Name: UITextField!
    @IBOutlet weak var CardsPerPlayer: UITextField!
    @IBOutlet weak var playBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
       //Closes keyboard when tap on view
        self.view.endEditing(true)
    }
    
    
    @IBAction func playBTN(_ sender: UIButton) {
        //sets variables and transitions to next view controller
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "WarVC") as! WarController
        
        secondVC.p1Cards = Int(CardsPerPlayer.text!)!
        secondVC.p2Cards = Int(CardsPerPlayer.text!)!
        secondVC.p1Name = p1Name.text!
        secondVC.p2Name = p2Name.text!
        self.present(secondVC, animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

