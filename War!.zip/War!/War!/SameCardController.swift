//
//  SameCardController.swift
//  War!
//
//  Created by David Richardson on 12/24/16.
//  Copyright © 2016 David Richardson. All rights reserved.
//

import UIKit

class SameCardController: UIViewController {
    
    
    @IBOutlet weak var p1NameLBL: UILabel!
    @IBOutlet weak var p2NameLBL: UILabel!
    @IBOutlet weak var Continue: lazyButton!
    @IBOutlet weak var p1i1: UIImageView!
    @IBOutlet weak var p1i2: UIImageView!
    @IBOutlet weak var p1i3: UIImageView!
    @IBOutlet weak var p2i1: UIImageView!
    @IBOutlet weak var p2i2: UIImageView!
    @IBOutlet weak var p2i3: UIImageView!
    
    var p1Name = ""
    var p2Name = ""
    var p1Cards = 0
    var p2Cards = 0
    
    let cards = ["2c", "2d", "2h", "2s", "3c", "3d", "3h", "3s", "4c", "4d", "4h", "4s", "5c", "5d", "5h", "5s", "6c", "6d", "6h", "6s", "7c", "7d", "7h", "7s", "8c", "8d", "8h", "8s", "9c", "9d", "9h", "9s", "10c", "10d", "10h", "10s", "jc", "jd", "jh", "js", "qc", "qd", "qh", "qs", "kc", "kd", "kh", "ks", "ac", "ad", "ah", "as"]
    //Dictionary Of Cards with Points And Immages
    let cardInfo = ["2c":[2],"2d":[2],"2h":[2],"2s":[2],"3c":[3],"3d":[3],"3h":[3],"3s":[3],"4c":[4],"4d":[4],"4h":[4],"4s":[4],"5c":[5],"5d":[5],"5h":[5],"5s":[5],   "6c":[6], "6d":[6],"6h":[6],"6s":[6],"7c":[7],"7d":[7],"7h":[7],"7s":[7],"8c":[8],
        "8d":[8],"8h":[8],"8s":[8],"9c":[9],"9d":[9],"9h":[9],"9s":[9],"10c":[10],"10d":[10],
        "10h":[10],"10s":[10],"jc":[11],"jd":[11],"jh":[11],"js":[11],"qc":[12],"qd":[12],
        "qh":[12],"qs":[12],"kc":[13],"kd":[13],"kh":[13],"ks":[13],"ac":[14],"ad":[14],
        "ah":[14],"as":[14]]
    var p1Points = 0
    var p2Points = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        p1NameLBL.text = p1Name
        p2NameLBL.text = p2Name
        pickP1Cards()
        pickP2Cards()
        gatherPoints(p1: p1Points, p2: p2Points)
    }
    func pickP1Cards(){
        let card1Name = cards[Int(arc4random_uniform(UInt32(cards.count)))]
        let card1Score = cardInfo[card1Name]?[0]
        let card2Name = cards[Int(arc4random_uniform(UInt32(cards.count)))]
        let card2Score = cardInfo[card2Name]?[0]
        let card3Name = cards[Int(arc4random_uniform(UInt32(cards.count)))]
        let card3Score = cardInfo[card3Name]?[0]
        setP1Picks(card1: card1Name, card2: card2Name, card3: card3Name)
        p1Points = card1Score!
        p1Points += card2Score!
        p1Points += card3Score!
        
    }
    func pickP2Cards(){
        let card1Name = cards[Int(arc4random_uniform(UInt32(cards.count)))]
        let card1Score = cardInfo[card1Name]?[0]
        let card2Name = cards[Int(arc4random_uniform(UInt32(cards.count)))]
        let card2Score = cardInfo[card2Name]?[0]
        let card3Name = cards[Int(arc4random_uniform(UInt32(cards.count)))]
        let card3Score = cardInfo[card3Name]?[0]
        setP2Picks(card1: card1Name, card2: card2Name, card3: card3Name)
        p2Points = card1Score!
        p2Points += card2Score!
        p2Points += card3Score!
    }
    func setP1Picks(card1:String, card2:String, card3:String){
        p1i1.image = UIImage(named: card1)
        p1i2.image = UIImage(named: card2)
        p1i3.image = UIImage(named: card3)
    }
    func setP2Picks(card1:String, card2:String, card3:String){
        p2i1.image = UIImage(named: card1)
        p2i2.image = UIImage(named: card2)
        p2i3.image = UIImage(named: card3)
    }
    func gatherPoints(p1:Int, p2:Int){
        if p1Points > p2Points {
            p1Cards += 3
            p2Cards -= 3
        }else if p2Points > p1Points {
            p2Cards += 3
            p1Cards -= 3
        }else{}
    }
    @IBAction func ContinueACT(_ sender: UIButton) {
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "WarVC") as! WarController
        
        secondVC.p1Cards = p1Cards
        secondVC.p2Cards = p2Cards
        secondVC.p1Name = p1Name
        secondVC.p2Name = p2Name
        print("sent p1Cards \(p1Cards), p2Cards \(p2Cards)")
        self.present(secondVC, animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
