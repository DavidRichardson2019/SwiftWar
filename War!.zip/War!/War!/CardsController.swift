//
//  CardsController.swift
//  War!
//
//  Created by David Richardson on 12/20/16.
//  Copyright © 2016 David Richardson. All rights reserved.
//

import UIKit

class CardsController: UIViewController {
    
    

    @IBOutlet weak var p2Image: UIImageView!
    //Should say p1 not pi but its too much work to fix
    @IBOutlet weak var piImage: UIImageView!
    @IBOutlet weak var p2NameLBL: UILabel!
    @IBOutlet weak var ContinueBTN: UIButton!
    @IBOutlet weak var p1NameLBL: UILabel!
    var p1Cards = 0
    var p2Cards = 0
    var p1Name = ""
    var p2Name = ""
    //Array of cards to randomly pick from
    let cards = ["2c", "2d", "2h", "2s", "3c", "3d", "3h", "3s", "4c", "4d", "4h", "4s", "5c", "5d", "5h", "5s", "6c", "6d", "6h", "6s", "7c", "7d", "7h", "7s", "8c", "8d", "8h", "8s", "9c", "9d", "9h", "9s", "10c", "10d", "10h", "10s", "jc", "jd", "jh", "js", "qc", "qd", "qh", "qs", "kc", "kd", "kh", "ks", "ac", "ad", "ah", "as"]
    //Dictionary Of Cards with Points And Immages
    let cardInfo = ["2c":[2],"2d":[2],"2h":[2],"2s":[2],"3c":[3],"3d":[3],"3h":[3],"3s":[3],"4c":[4],"4d":[4],"4h":[4],"4s":[4],"5c":[5],"5d":[5],"5h":[5],"5s":[5],   "6c":[6], "6d":[6],"6h":[6],"6s":[6],"7c":[7],"7d":[7],"7h":[7],"7s":[7],"8c":[8],
        "8d":[8],"8h":[8],"8s":[8],"9c":[9],"9d":[9],"9h":[9],"9s":[9],"10c":[10],"10d":[10],
        "10h":[10],"10s":[10],"jc":[11],"jd":[11],"jh":[11],"js":[11],"qc":[12],"qd":[12],
        "qh":[12],"qs":[12],"kc":[13],"kd":[13],"kh":[13],"ks":[13],"ac":[14],"ad":[14],
        "ah":[14],"as":[14]]
    var draw = false
    override func viewDidLoad() {
        super.viewDidLoad()
        p1NameLBL.text = p1Name
        p2NameLBL.text = p2Name
        pickCard()
    }
    func pickCard(){
        //Chooses first random card and gets points
        let cardName = cards[Int(arc4random_uniform(UInt32(cards.count)))]
        var cardScore = cardInfo[cardName]?[0]
        //second
        let cardName2 = cards[Int(arc4random_uniform(UInt32(cards.count)))]
        let cardScore2 = cardInfo[cardName2]?[0]
        /* UNCOMMENT NEXT LINE TO SIMMULATE PULLING THE SAME CARD */
        // cardScore = cardScore2
        if cardScore == cardScore2 {
            same()
        }
        updateLBLs(card1: cardName, card2: cardName2)
        if cardScore! > cardScore2! {
            p2Cards -= 1
            p1Cards += 1
            print("p1 Wins")
        }else if cardScore2! > cardScore! {
            p1Cards -= 1
            p2Cards += 1
            print("p2Wins")
        }
    }
    func same(){
        ContinueBTN.setTitle("Draw!", for: .normal)
        draw = true
    }
    func updateLBLs(card1: String, card2: String){
        piImage.image = UIImage(named: card1)
        p2Image.image = UIImage(named: card2)
    }
    @IBAction func ContinueBTN(_ sender: UIButton) {
        if(draw == false){
            //Set ariables and transition to WarVC
            let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "WarVC") as! WarController
        
            secondVC.p1Cards = p1Cards
            secondVC.p2Cards = p2Cards
            secondVC.p1Name = p1Name
            secondVC.p2Name = p2Name
            print("sent p1Cards \(p1Cards), p2Cards \(p2Cards)")
            self.present(secondVC, animated: true, completion: nil)
        }else {
            let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SameVC") as! SameCardController
            
            secondVC.p1Cards = p1Cards
            secondVC.p2Cards = p2Cards
            secondVC.p1Name = p1Name
            secondVC.p2Name = p2Name
            print("sent p1Cards \(p1Cards), p2Cards \(p2Cards)")
            self.present(secondVC, animated: true, completion: nil)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
