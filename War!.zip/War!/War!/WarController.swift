//
//  WarController.swift
//  War!
//
//  Created by David Richardson on 12/19/16.
//  Copyright © 2016 David Richardson. All rights reserved.
//

import UIKit

class WarController: UIViewController {

    @IBOutlet weak var WinningLBL: UILabel!
    @IBOutlet weak var p2NameLBL: UILabel!
    @IBOutlet weak var warBtn: UIButton!
    @IBOutlet weak var p1NameLBL: UILabel!
    @IBOutlet weak var p2LBL: UILabel!
    @IBOutlet weak var p1LBL: UILabel!
    var p1Cards = 0
    var p2Cards = 0
    var p1Name = ""
    var p2Name = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        if p1Cards == 0 || p2Cards == 0 {
            //If Somone won change button text
            warBtn.setTitle("Main Menu", for: .normal)
        }
        //Changing card labels
        p2LBL.text = String(p2Cards)
        p1LBL.text = String(p1Cards)
        //Changing name labels
        p1NameLBL.text = p1Name
        p2NameLBL.text = p2Name
        //Changing ahead label
        if p1Cards == 0 {
            WinningLBL.text = "\(p2Name) Winns!"
        }else if p2Cards == 0 {
            WinningLBL.text = "\(p1Name) Winns!"
        }else if p1Cards == p2Cards {
            WinningLBL.text = "All Tied Up"
        }else if p1Cards > p2Cards {
            WinningLBL.text = "\(p1Name) is ahead"
        }else {
            WinningLBL.text = "\(p2Name) is ahead"
        }
    }
    func goToCards(){
        //Changing variables and transitioning to card view
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "CardsVC") as! CardsController
        
        secondVC.p1Cards = p1Cards
        secondVC.p2Cards = p2Cards
        print("set p1Cards to \(p1Cards) and p2Cards to \(p2Cards)")
        secondVC.p1Name = p1Name
        secondVC.p2Name = p2Name
        print("set p1Name to \(p1Name) and p2Name to \(p2Name)")
        self.present(secondVC, animated: true, completion: nil)
    }
    func goToMain() {
        //Transitioning to main view
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "MainVC") as! StartController
        self.present(secondVC, animated: true, completion: nil)
    }
    @IBAction func WarBTN(_ sender: UIButton) {
        if p1Cards == 0 || p2Cards == 0{
            goToMain()
        }else {
            goToCards()
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
