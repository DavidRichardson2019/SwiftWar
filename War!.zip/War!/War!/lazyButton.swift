//
//  lazyButton.swift
//  War!
//
//  Created by David Richardson on 12/23/16.
//  Copyright © 2016 David Richardson. All rights reserved.
//

import UIKit

class lazyButton: UIButton {
    required public init?(coder aDecoder: NSCoder) {
        
        super.init(coder: aDecoder)
        
        self.layer.cornerRadius = 5
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.black.cgColor
        self.backgroundColor = UIColor.black
        self.setTitleColor(UIColor.white, for: .normal)
        
    }

}
